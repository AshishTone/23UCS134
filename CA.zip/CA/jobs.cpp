#include <stdio.h>
#include <stdbool.h>

int main() {
    int n, i, j;

    printf("Enter number of jobs: ");
    scanf("%d", &n);

    int profit[100], deadline[100];

    printf("Enter profits:\n");
    for (i = 0; i < n; i++)
        scanf("%d", &profit[i]);

    printf("Enter deadlines:\n");
    for (i = 0; i < n; i++)
        scanf("%d", &deadline[i]);

    // ?? Bubble Sort: Sort jobs by profit (high to low)
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (profit[j] < profit[j + 1]) {
                // Swap profit
                int temp = profit[j];
                profit[j] = profit[j + 1];
                profit[j + 1] = temp;

                // Swap corresponding deadline
                temp = deadline[j];
                deadline[j] = deadline[j + 1];
                deadline[j + 1] = temp;
            }
        }
    }

    // ?? Find max deadline
    int maxDeadline = 0;
    for (i = 0; i < n; i++)
        if (deadline[i] > maxDeadline)
            maxDeadline = deadline[i];

    bool slot[maxDeadline] = {false}; // To keep track of free time slots
    int totalProfit = 0;

    // ?? Schedule jobs
    for (i = 0; i < n; i++) {
        for (j = deadline[i] - 1; j >= 0; j--) {
            if (!slot[j]) {
                slot[j] = true;         // Assign job to slot
                totalProfit += profit[i]; // Add profit
                break;
            }
        }
    }

    printf("Maximum total profit: %d\n", totalProfit);

    return 0;
}

