#include <stdio.h>
#include <stdlib.h>

// Comparator function to sort intervals by end time
int compare(const void* a, const void* b) {
    int* intA = *(int**)a;
    int* intB = *(int**)b;
    return intA[1] - intB[1];
}

// Main logic to find minimum number of intervals to remove
int eraseOverlapIntervals(int** intervals, int intervalsSize, int* intervalsColSize) {
    if (intervalsSize == 0) return 0;

    // Sort intervals by end time
    qsort(intervals, intervalsSize, sizeof(int*), compare);

    int count = 1; // Count the first interval
    int end = intervals[0][1];

    for (int i = 1; i < intervalsSize; i++) {
        if (intervals[i][0] >= end) {
            count++;
            end = intervals[i][1];
        }
    }

    return intervalsSize - count;
}

int main() {
    int n;
    printf("Enter the number of intervals: ");
    scanf("%d", &n);

    // Dynamically allocate memory for intervals
    int** intervals = (int**)malloc(n * sizeof(int*));
    int* intervalsColSize = (int*)malloc(n * sizeof(int)); // All are 2

    printf("Enter the intervals (start and end for each):\n");
    for (int i = 0; i < n; i++) {
        intervals[i] = (int*)malloc(2 * sizeof(int));
        scanf("%d %d", &intervals[i][0], &intervals[i][1]);
        intervalsColSize[i] = 2; // each interval has 2 values
    }

    int result = eraseOverlapIntervals(intervals, n, intervalsColSize);
    printf("Minimum number of intervals to remove: %d\n", result);

    // Free allocated memory
    for (int i = 0; i < n; i++) {
        free(intervals[i]);
    }
    free(intervals);
    free(intervalsColSize);

    return 0;
}

