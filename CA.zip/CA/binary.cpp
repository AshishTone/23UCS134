#include<stdio.h>
void search(int n , int a[] , int target)
{
	int low = 0,high = n -1;
	while(low <= high)
	 {
	
	int mid = (low+high)/2;
	if(a[mid] == target)
	{
		printf("\nThe element is found at %d",mid);
		break;
	}
	
	if(a[mid] < target)
	{
		low = mid + 1;
	}
	else
	{
		high = mid -1;
	}
	
	}
	
	
}

void sort(int n , int a[],int target)
{
	int i ,j;
	for( i =0 ; i < n-1 ; i++)
	{
		for(j = 0; j < n-1-i ; j++)
		{
			if(a[j] > a[j + 1])
			{
				int temp = a[j];
				a[j] = a[j + 1];
				a[j+1] = temp;
			}
		}
	}
	printf("Sorted Array:");
	for(i = 0 ; i < n ;i++)
	{
		printf("%d\t",a[i]);
	}
	search(n , a , target);
}




int main()
{
	int n , i ,j;
	printf("Enter the size: ");
	scanf("%d",&n);
	
	int a[n];
	printf("Enter the elemnets: ");
	for(i = 0 ;i < n ;i++)
	{
		scanf("%d",&a[i]);
	}
	int target;
	printf("Enter the target: ");
	scanf("%d",&target);
	sort(n , a , target);
	
	return 0;
}

