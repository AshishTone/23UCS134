#include <stdio.h>

// Helper function to swap two elements
void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Partition function (Lomuto partition scheme)
int partition(int* nums, int left, int right) {
    int pivot = nums[right];
    int i = left;

    for (int j = left; j < right; j++) {
        if (nums[j] >= pivot) { // For kth largest
            swap(&nums[i], &nums[j]);
            i++;
        }
    }
    swap(&nums[i], &nums[right]);
    return i;
}

// Quickselect algorithm
int quickSelect(int* nums, int left, int right, int k) {
    if (left <= right) {
        int pi = partition(nums, left, right);

        if (pi == k)
            return nums[pi];
        else if (pi > k)
            return quickSelect(nums, left, pi - 1, k);
        else
            return quickSelect(nums, pi + 1, right, k);
    }
    return -1;
}

// Main function as asked
int findKthLargest(int* nums, int numsSize, int k) {
    return quickSelect(nums, 0, numsSize - 1, k - 1); // k-1 because of 0-based index
}
int main() {
    int nums[] = {3, 2, 3, 1, 2, 4, 5, 5, 6};
    int k = 4;
    int n = sizeof(nums) / sizeof(nums[0]);

    int result = findKthLargest(nums, n, k);
    printf("The %dth largest element is: %d\n", k, result);

    return 0;
}

