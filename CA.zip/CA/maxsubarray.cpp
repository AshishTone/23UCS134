#include <stdio.h>
#include <limits.h>

// Function to find the maximum sum that crosses the middle of the array
int maxCrossingSum(int arr[], int left, int mid, int right) {
    int sum = 0;
    int leftSum = INT_MIN;

    // Find max sum of left subarray ending at mid
    for (int i = mid; i >= left; i--) {
        sum += arr[i];
        if (sum > leftSum)
            leftSum = sum;
    }

    sum = 0;
    int rightSum = INT_MIN;

    // Find max sum of right subarray starting at mid+1
    for (int i = mid + 1; i <= right; i++) {
        sum += arr[i];
        if (sum > rightSum)
            rightSum = sum;
    }

    // Total max crossing sum is left part + right part
    return leftSum + rightSum;
}

// Recursive function to find the max subarray sum using Divide and Conquer
int maxSubArrayHelper(int arr[], int left, int right) {
    if (left == right)
        return arr[left];  // Base case: one element

    int mid = (left + right) / 2;

    // Recursively find max in left, right, and cross
    int leftMax = maxSubArrayHelper(arr, left, mid);
    int rightMax = maxSubArrayHelper(arr, mid + 1, right);
    int crossMax = maxCrossingSum(arr, left, mid, right);

    // Return the overall max
    if (leftMax >= rightMax && leftMax >= crossMax)
        return leftMax;
    else if (rightMax >= leftMax && rightMax >= crossMax)
        return rightMax;
    else
        return crossMax;
}

// Main function that starts the process
int maxSubArray(int* nums, int numsSize) {
    return maxSubArrayHelper(nums, 0, numsSize - 1);
}

int main() {
    int n;
     printf("enter size: \n");
     scanf("%d",&n);
     int nums[n];
     printf("enter elemnts: \n");
     int i;
     for(i=0;i<n;i++){
     	scanf("%d",&nums[i]);
	 }
	  
    int result = maxSubArray(nums, n);
    printf("Maximum subarray sum is: %d\n", result);

    return 0;
}

