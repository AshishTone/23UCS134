#include <stdio.h>

// Function to swap two numbers using array indexes
void swap(int arr[], int i, int j) {
    int temp;
    temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

// Partition function to put smaller numbers on left, bigger on right
int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // pick last number as pivot
    int i = low;

    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            swap(arr, i, j);
            i++;
        }
    }

    swap(arr, i, high); // put pivot in correct position
    return i;
}

// The quick sort function
void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high); // find pivot position

        // Sort the two halves
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Function to print the array
void printArray(int arr[], int size) {
    printf("Sorted numbers: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Main function
int main() {
    int arr[100];
    int n;

    printf("How many numbers? ");
    scanf("%d", &n);

    printf("Enter the numbers:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    quickSort(arr, 0, n - 1); // Call quick sort
    printArray(arr, n);       // Print the sorted array

    return 0;
}
