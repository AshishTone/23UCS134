#include <stdio.h>

#define INF 9999
#define MAX 100

int main() {
    int n, i, j, u, v, min, cost[MAX][MAX], visited[MAX] = {0}, ne = 1, mincost = 0;

    printf("Enter the number of vertices: ");
    scanf("%d", &n);

    printf("Enter the adjacency matrix (use 0 for no edge):\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            scanf("%d", &cost[i][j]);
            if (cost[i][j] == 0)
                cost[i][j] = INF;
        }

    visited[0] = 1; // Start from the first vertex

    printf("Edges in the Minimum Spanning Tree:\n");
    while (ne < n) {
        min = INF;
        for (i = 0; i < n; i++) {
            if (visited[i]) {
                for (j = 0; j < n; j++) {
                    if (!visited[j] && cost[i][j] < min) {
                        min = cost[i][j];
                        u = i;
                        v = j;
                    }
                }
            }
        }
        printf("%d - %d : %d\n", u + 1, v + 1, min);
        mincost += min;
        visited[v] = 1;
        ne++;
    }

    printf("Minimum cost = %d\n", mincost);
    return 0;
}
