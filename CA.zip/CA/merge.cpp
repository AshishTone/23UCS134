#include <stdio.h>

#define MAX 100

int a[MAX]; // main array
int b[MAX]; // auxiliary array used during merge

// Merge function to combine two sorted parts of array
void Merge(int low, int mid, int high) {
    int h = low;
    int i = low;
    int j = mid + 1;

    // Merge both halves into b[]
    while (h <= mid && j <= high) {
        if (a[h] <= a[j]) {
            b[i] = a[h];
            h++;
        } else {
            b[i] = a[j];
            j++;
        }
        i++;
    }

    // If left part is remaining
    while (h <= mid) {
        b[i] = a[h];
        h++;
        i++;
    }

    // If right part is remaining
    while (j <= high) {
        b[i] = a[j];
        j++;
        i++;
    }

    // Copy sorted elements back into original array a[]
    for (int k = low; k <= high; k++) {
        a[k] = b[k];
    }
}

// Merge Sort function using divide and conquer
void MergeSort(int low, int high) {
    if (low < high) {
        int mid = (low + high) / 2;
        MergeSort(low, mid);        // Sort left half
        MergeSort(mid + 1, high);   // Sort right half
        Merge(low, mid, high);      // Merge the sorted halves
    }
}

// Function to print array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

// Main function
int main() {
    int n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Original array:\n");
    printArray(a, n);

    MergeSort(0, n - 1);

    printf("Sorted array:\n");
    printArray(a, n);

    return 0;
}

