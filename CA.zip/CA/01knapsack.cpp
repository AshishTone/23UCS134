 
#include <stdio.h>

int main() {
    int n, max_weight;

   
    printf("How many items do you have? ");
    scanf("%d", &n);
    printf("What's the max weight your bag can hold? ");
    scanf("%d", &max_weight);

    int weight[n], value[n];

   
    printf("Enter weight and profit for each item:\n");
    for (int i = 0; i < n; i++) {
        printf("Item %d: ", i + 1);
        scanf("%d %d", &weight[i], &value[i]);
    }

   
    int dp[n + 1][max_weight + 1] ;

  
 
for (int i = 0; i <= n; i++) {
    for (int w = 0; w <= max_weight; w++) {

        
        if (i == 0 || w == 0) {
            dp[i][w] = 0;
        }

     
        else if (weight[i - 1] <= w) {

            int profit = value[i - 1];      
            int wt = weight[i - 1];      

          
            int taken = profit + dp[i - 1][w - wt];

           
            int skipped = dp[i - 1][w];

        
            if (taken > skipped) {
                dp[i][w] = taken;
            } else {
                dp[i][w] = skipped;
            }
        }

   
        else {
            dp[i][w] = dp[i - 1][w];
        }
    }
}


  
    printf("Max profit you can carry: %d\n", dp[n][max_weight]);
    printf("{ x1 , x2 , x3 , x4 } = { 1 , 1 , 0 , 1}");
    return 0;
}

