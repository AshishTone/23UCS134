#include <stdio.h>
#include <stdlib.h>
 void merge(int*nums, int left, int mid , int right){
     int n1 = mid-left+1;
     int n2= right-mid;

     int*L =(int*)malloc(n1*sizeof(int));
     int* R=(int*)malloc(n2*sizeof(int));

     for(int i=0;i<n1;i++){
        L[i]=nums[left+i];
     }
     for(int j=0;j<n2;j++){
        R[j]=nums[mid+1+j];
     }
     int i=0, j=0, k= left;
     while(i<n1&&j<n2){
        if(L[i]<=R[j]){
            nums[k++]=L[i++];
        }
        else{
            nums[k++]=R[j++];
        }

        while(i<n1){
             nums[k++]=L[i++];

        }
        while(j<n2){
             nums[k++]=R[j++];
        }
        free(L);
        free(R);

     }
 } 

 void mergesort(int*nums,int left, int right){
    if (left<right){
        int mid=(left+right)/2;
        mergesort(nums,left,mid);
        mergesort(nums,mid+1,right);
        merge(nums,left,mid,right);

    }
 }
int* sortArray(int* nums, int numsSize, int* returnSize) {
    mergesort(nums,0,numsSize-1);
    *returnSize=numsSize;
    return nums;
    
}


int main() {
    int n; 
     printf("enter size: \n");
     scanf("%d",&n);
     int nums[n];
     printf("enter elemnts: \n");
     int i;
     for(i=0;i<n;i++){
     	scanf("%d",&nums[i]);
	 }
    int returnSize;

    int* sorted = sortArray(nums, n, &returnSize);

    printf("Sorted array: ");
    for (int i = 0; i < returnSize; i++) {
        printf("%d ", sorted[i]);
    }
    printf("\n");

    return 0;
}

