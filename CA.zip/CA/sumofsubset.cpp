#include <stdio.h>

#define MAX 20

int set[MAX];        // Array to store the input set
int n;               // Number of elements in the set
int targetSum;       // The sum we want subsets to add up to
int subset[MAX];     // Array to store the current subset

// Function to print a subset
void printSubset(int subset[], int size) {
    printf("{ ");
    for (int i = 0; i < size; i++) {
        printf("%d ", subset[i]);
    }
    printf("}\n");
}

// Backtracking function to find subsets that sum to target
void findSubsets(int i, int currentSum, int subsetSize) {
    // If currentSum equals targetSum, print the subset
    if (currentSum == targetSum) {
        printSubset(subset, subsetSize);
        return;
    }

    // If we have considered all elements or currentSum exceeds targetSum, stop exploring
    if (i == n || currentSum > targetSum) {
        return;
    }

    // Include the current element and move to next
    subset[subsetSize] = set[i];
    findSubsets(i + 1, currentSum + set[i], subsetSize + 1);

    // Exclude the current element and move to next
    findSubsets(i + 1, currentSum, subsetSize);
}

int main() {
    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d positive integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &set[i]);
    }

    printf("Enter target sum: ");
    scanf("%d", &targetSum);

    printf("Subsets that sum to %d are:\n", targetSum);
    findSubsets(0, 0, 0);

    return 0;
}

