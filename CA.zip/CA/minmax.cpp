#include <stdio.h>

// This function returns the smallest number
int findMin(int arr[], int start, int end) {
    if (start == end) {
        return arr[start];
    } else {
        int mid = (start + end) / 2;
        int min1 = findMin(arr, start, mid);
        int min2 = findMin(arr, mid + 1, end);

        if (min1 < min2)
            return min1;
        else
            return min2;
    }
}

// This function returns the biggest number
int findMax(int arr[], int start, int end) {
    if (start == end) {
        return arr[start];
    } else {
        int mid = (start + end) / 2;
        int max1 = findMax(arr, start, mid);
        int max2 = findMax(arr, mid + 1, end);

        if (max1 > max2)
            return max1;
        else
            return max2;
    }
}

int main() {
    int arr[100], n;

    printf("How many numbers? ");
    scanf("%d", &n);

    printf("Enter the numbers:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Call functions to find min and max
    int min = findMin(arr, 0, n - 1);
    int max = findMax(arr, 0, n - 1);

    printf("Smallest number is: %d\n", min);
    printf("Biggest number is: %d\n", max);

    return 0;
}
