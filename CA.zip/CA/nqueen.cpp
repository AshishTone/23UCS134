#include <stdio.h>
#include <stdbool.h>

#define MAX 10

int board[MAX];  // board[i] = column where queen is placed in row i
int n;           // Size of the chessboard (N x N)

// Function to check if placing a queen at row and col is safe
bool isSafe(int row, int col) {
    for (int i = 0; i < row; i++) {
        // Check column and diagonals
        if (board[i] == col ||                     // Same column
            board[i] - i == col - row ||           // Same main diagonal
            board[i] + i == col + row)             // Same anti-diagonal
            return false;
    }
    return true;
}

// Function to print the board
void printBoard() {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (board[i] == j)
                printf("Q ");
            else
                printf(". ");
        }
        printf("\n");
    }
    printf("\n");
}

// Backtracking function to solve N-Queens
void solve(int row) {
    if (row == n) {
        printBoard(); // All queens placed successfully
        return;
    }

    // Try placing queen in all columns one by one
    for (int col = 0; col < n; col++) {
        if (isSafe(row, col)) {
            board[row] = col;    // Place queen
            solve(row + 1);      // Move to next row
            // Backtrack: No need to undo board[row], it will be overwritten
        }
    }
}

int main() {
    printf("Enter value of N (size of board): ");
    scanf("%d", &n);

    printf("Solutions to %d-Queens problem:\n\n", n);
    solve(0);  // Start from the first row

    return 0;
}

