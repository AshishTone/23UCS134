#include<stdio.h>

int main()
{
	int n , m , i , j;
	
	printf("Enter the total number of items: ");
	scanf("%d",&n);
	
	printf("Enter the size of Sack: ");
	scanf("%d",&m);
	
	int profit[n],weight[n];
	
	printf("Enter the profit of items: ");
	for(i = 0 ; i < n ; i++)
	{
		scanf("%d",&profit[i]);
	}
	
	printf("Enter the weight of items: ");
	for(i = 0 ; i < n ; i++)
	{
		scanf("%d",&weight[i]);
	}
	
	float div[n];
	
	for(i = 0 ; i < n ; i++)
	{
		div[i] =(float) profit[i]/weight[i];
	}
	
	
	// Arranging in the decreasing order
	 for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (div[j] < div[j + 1]) {
                
                float temp_ratio = div[j];
                div[j] = div[j + 1];
                div[j + 1] = temp_ratio;

                
                int temp_weight = weight[j];
                weight[j] = weight[j + 1];
                weight[j + 1] = temp_weight;

            
                int temp_profit = profit[j];
                profit[j] = profit[j + 1];
                profit[j + 1] = temp_profit;
            }
        }
    }
	
	
	// Calcaluting the maximum profit
	float total_profit = 0.0;
    int current_weight = 0;

    for (int i = 0; i < n; i++) {
        if (current_weight + weight[i] <= m) {
           
            current_weight += weight[i];
            total_profit += profit[i];
        } else {
     
            int remaining_capacity = m - current_weight;
            total_profit += profit[i] * ((float)remaining_capacity / weight[i]);
            break; 
        }
    }


	printf("The maximum profit : %.2f",total_profit);


	
	
	return 0;
}
