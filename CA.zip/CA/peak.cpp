#include <stdio.h>

// Function to find a peak element
int findPeakElement(int* nums, int numsSize) {
    int low = 0;
    int high = numsSize - 1;

    while (low < high) {
        int mid = (low + high) / 2;

        // Compare mid element with next element
        if (nums[mid] > nums[mid + 1]) {
            // Peak is in the left half (including mid)
            high = mid;
        } else {
            // Peak is in the right half (excluding mid)
            low = mid + 1;
        }
    }

    // low == high is the peak index
    return low;
}

int main() {
    int n;
     printf("enter size: \n");
     scanf("%d",&n);
     int nums[n];
     printf("enter elemnts: \n");
     int i;
     for(i=0;i<n;i++){
     	scanf("%d",&nums[i]);
	 }
	  

    int peakIndex = findPeakElement(nums, n);
    printf("Peak element is at index: %d\n", peakIndex);

    return 0;
}

